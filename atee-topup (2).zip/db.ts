
import { Order, OrderStatus, Installment, User, Game, Package, GameForm, PromoBanner, SystemSettings, Coupon, Review, ApiConfig } from './types';
import { GAMES, PACKAGES, PROMOS, COUPONS, API_CONFIGS } from './constants';
import { db } from './firebaseConfig';
import { 
  collection, addDoc, setDoc, doc, updateDoc, getDocs, 
  query, where, deleteDoc, onSnapshot, orderBy, limit
} from 'firebase/firestore';

export const DB = {
  // ฟังก์ชันสำหรับ Initialize Data ลง Firestore ครั้งแรก
  seedDatabase: async () => {
    if (!db) return;
    
    // 1. Check & Seed Games
    const gamesSnap = await getDocs(collection(db, 'games'));
    if (gamesSnap.empty) {
      console.log('Seeding Games...');
      const batchPromises = GAMES.map(g => setDoc(doc(db, 'games', g.id), g));
      await Promise.all(batchPromises);
    }

    // 2. Check & Seed Packages
    const pkgsSnap = await getDocs(collection(db, 'packages'));
    if (pkgsSnap.empty) {
      console.log('Seeding Packages...');
      const batchPromises = PACKAGES.map(p => setDoc(doc(db, 'packages', p.id), p));
      await Promise.all(batchPromises);
    }

    // 3. Check & Seed Promos
    const promosSnap = await getDocs(collection(db, 'promos'));
    if (promosSnap.empty) {
      console.log('Seeding Promos...');
      const batchPromises = PROMOS.map(p => setDoc(doc(db, 'promos', p.id), p));
      await Promise.all(batchPromises);
    }

    // 4. Check & Seed Coupons
    const couponsSnap = await getDocs(collection(db, 'coupons'));
    if (couponsSnap.empty) {
      console.log('Seeding Coupons...');
      const batchPromises = COUPONS.map(c => setDoc(doc(db, 'coupons', c.id), c));
      await Promise.all(batchPromises);
    }

    // 5. Check & Seed Api Configs
    const apiSnap = await getDocs(collection(db, 'api_configs'));
    if (apiSnap.empty) {
      console.log('Seeding API Configs...');
      const batchPromises = API_CONFIGS.map(a => setDoc(doc(db, 'api_configs', a.id), a));
      await Promise.all(batchPromises);
    }

    // 6. Check & Seed Settings
    const settingsSnap = await getDocs(collection(db, 'settings'));
    if (settingsSnap.empty) {
      console.log('Seeding Default Settings...');
      const defSettings: SystemSettings = {
        promptPayId: "0863058154",
        promptPayName: "บจก. เอที ท็อปอัพ",
        truemoneyPhone: "0863058154",
        truemoneyName: "ATEE TOPUP",
        isInstallmentEnabled: true,
        isMaintenanceMode: false,
        forceLogin: true,
        contactLine: "@ATEETOPUP",
        terms: "1. ตรวจสอบไอดีให้ถูกต้อง\n2. เติมแล้วไม่สามารถยกเลิกได้",
        flashSaleEnabled: true,
        isSlipVerifyEnabled: true,
        slipVerifyApiKey: "DEMO_KEY",
        announcement: "ยินดีต้อนรับสู่ ATEE TOPUP เติมเกมราคาถูก ตลอด 24 ชม.",
        contactChannels: [
          { id: 'c1', name: 'Facebook', value: 'ATEE TOPUP', url: '#' },
          { id: 'c2', name: 'Line', value: '@ATEETOPUP', url: '#' }
        ]
      };
      await setDoc(doc(db, 'settings', 'global'), defSettings);
    }

    console.log('Database Initialization Complete');
  },

  subscribe: (collectionName: string, callback: (data: any[]) => void) => {
    if (!db) return () => {};
    const q = query(collection(db, collectionName));
    return onSnapshot(q, (snapshot) => {
      const data: any[] = [];
      snapshot.forEach((doc) => {
        data.push({ ...doc.data(), id: doc.id });
      });
      // Cache to local storage for faster initial load next time
      localStorage.setItem(`atee_${collectionName}`, JSON.stringify(data));
      callback(data);
    }, (error) => {
      console.error(`Subscription error for ${collectionName}:`, error);
    });
  },

  verifyPlayerId: async (gameId: string, playerId: string): Promise<string | null> => {
    // Fetch configs directly or from cache
    let apiConfigs = JSON.parse(localStorage.getItem('atee_api_configs') || '[]');
    if (apiConfigs.length === 0 && db) {
        const snap = await getDocs(collection(db, 'api_configs'));
        apiConfigs = snap.docs.map(d => ({...d.data(), id: d.id}));
    }

    const games = DB.getGames();
    const game = games.find((g: any) => g.id === gameId);
    
    if (!game || !game.isVerifyEnabled || !game.apiConfigId) return null;
    const config = apiConfigs.find((c: any) => c.id === game.apiConfigId);
    if (!config) return null;

    try {
      const url = config.endpoint.replace('{id}', encodeURIComponent(playerId));
      const response = await fetch(url, {
        method: config.method,
        headers: JSON.parse(config.headers || '{}')
      });
      if (!response.ok) return null;
      
      const data = await response.json();
      const path = config.responsePath.split('.');
      let result = data;
      for (const key of path) {
        result = result?.[key];
      }
      return result ? String(result) : null;
    } catch (e) {
      console.error("Verification API Error:", e);
      return null;
    }
  },

  fetchUserOrders: async (userId: string) => {
    if (!db) return [];
    try {
      const q = query(
        collection(db, 'orders'), 
        where('userId', '==', userId)
      );
      const snap = await getDocs(q);
      const data: Order[] = [];
      snap.forEach(doc => data.push({ ...doc.data(), id: doc.id } as Order));
      data.sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
      const limitedData = data.slice(0, 50);
      localStorage.setItem('atee_orders', JSON.stringify(limitedData));
      return limitedData;
    } catch (err) {
      console.error("Error fetching orders:", err);
      return JSON.parse(localStorage.getItem('atee_orders') || '[]');
    }
  },

  getOrders: (): Order[] => {
    const stored = localStorage.getItem('atee_orders');
    return stored ? JSON.parse(stored) : [];
  },

  saveOrder: async (order: Order) => {
    if (db) {
      try {
        await setDoc(doc(db, 'orders', order.id), order);
        const current = DB.getOrders();
        // Optimistic update local
        localStorage.setItem('atee_orders', JSON.stringify([order, ...current.filter(o => o.id !== order.id)]));
      } catch (e) {
        console.error("Save Order Error:", e);
      }
    }
  },

  updateOrderStatus: async (id: string, status: OrderStatus, adminNote?: string, verificationData?: any) => {
    if (db) {
      const updateObj: any = { status };
      if (adminNote) updateObj.adminNote = adminNote;
      if (verificationData) updateObj.verificationData = verificationData;
      await updateDoc(doc(db, 'orders', id), updateObj);
    }
  },

  getGames: (): Game[] => {
    const stored = localStorage.getItem('atee_games');
    return stored ? JSON.parse(stored) : GAMES;
  },

  getPackages: (): Package[] => {
    const stored = localStorage.getItem('atee_packages');
    return stored ? JSON.parse(stored) : PACKAGES;
  },

  getSettings: (): SystemSettings => {
    const stored = localStorage.getItem('atee_settings');
    if (stored) {
      const parsed = JSON.parse(stored);
      // Handle both array format from fetchCollection or single object
      if (Array.isArray(parsed)) return parsed.find((s: any) => s.id === 'global') || parsed[0];
      return parsed;
    }
    // Fallback default
    return {
      promptPayId: "0863058154",
      promptPayName: "บจก. เอที ท็อปอัพ",
      truemoneyPhone: "0863058154",
      truemoneyName: "ATEE TOPUP",
      isInstallmentEnabled: true,
      isMaintenanceMode: false,
      forceLogin: true,
      contactLine: "@ATEETOPUP",
      terms: "Loading...",
      flashSaleEnabled: true,
      isSlipVerifyEnabled: false
    };
  },

  fetchCollection: async <T>(name: string): Promise<T[]> => {
    if (!db) return [];
    try {
      const q = query(collection(db, name));
      const snap = await getDocs(q);
      const data: T[] = [];
      snap.forEach(doc => data.push({ ...doc.data(), id: doc.id } as T));
      if (data.length > 0) {
        localStorage.setItem(`atee_${name}`, JSON.stringify(data));
      }
      return data;
    } catch (err) {
      console.error(`Error fetching ${name}:`, err);
      return JSON.parse(localStorage.getItem(`atee_${name}`) || '[]');
    }
  },
  
  saveReview: async (review: Review) => {
    if (db) await setDoc(doc(db, 'reviews', review.id), review);
  },

  getReviews: (): Review[] => JSON.parse(localStorage.getItem('atee_reviews') || '[]'),
  getPromos: (): PromoBanner[] => JSON.parse(localStorage.getItem('atee_promos') || '[]'),
  getForms: (): GameForm[] => JSON.parse(localStorage.getItem('atee_forms') || '[]'),
  getCoupons: (): Coupon[] => JSON.parse(localStorage.getItem('atee_coupons') || '[]'),
  getInstallments: (): Installment[] => JSON.parse(localStorage.getItem('atee_installments') || '[]'),
  
  saveUser: async (user: User) => {
    if (db) await setDoc(doc(db, 'users', user.id), user);
  },

  verifySlip: async (image: string, amount: number, settings: SystemSettings) => {
    // Simulation for demo purposes
    await new Promise(r => setTimeout(r, 4000)); 
    const isSuccess = Math.random() > 0.1; 
    return {
      success: isSuccess,
      data: isSuccess ? { transRef: "TXN" + Date.now(), amount: amount, senderName: "Customer" } : null
    };
  },

  saveGame: async (game: Game) => {
    if (db) await setDoc(doc(db, 'games', game.id), game);
  },

  savePackage: async (pkg: Package) => {
    if (db) await setDoc(doc(db, 'packages', pkg.id), pkg);
  },

  saveForm: async (form: GameForm) => {
    if (db) await setDoc(doc(db, 'forms', form.gameId), form);
  },

  updateUser: async (user: User) => {
    if (db) await setDoc(doc(db, 'users', user.id), user);
  },

  savePromo: async (promo: PromoBanner) => {
    if (db) await setDoc(doc(db, 'promos', promo.id), promo);
  },

  deletePromo: async (id: string) => {
    if (db) await deleteDoc(doc(db, 'promos', id));
  },

  saveCoupon: async (coupon: Coupon) => {
    if (db) await setDoc(doc(db, 'coupons', coupon.id), coupon);
  },

  deleteCoupon: async (id: string) => {
    if (db) await deleteDoc(doc(db, 'coupons', id));
  },

  saveSettings: async (settings: SystemSettings) => {
    if (db) await setDoc(doc(db, 'settings', 'global'), settings);
  },

  updateInstallment: async (id: string, data: Partial<Installment>) => {
    if (db) await updateDoc(doc(db, 'installments', id), data);
  },

  saveApiConfig: async (config: ApiConfig) => {
    if (db) await setDoc(doc(db, 'api_configs', config.id), config);
  },

  deleteReview: async (id: string) => {
    if (db) await deleteDoc(doc(db, 'reviews', id));
  }
};
