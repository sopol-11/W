
# ATEE TOPUP - ระบบเติมเกมพรีเมียม

ระบบเติมเกมอัตโนมัติ ดีไซน์ Pastel ขอบโค้งมน 50px พร้อมระบบหลังบ้าน (Admin Panel) และระบบผ่อนชำระ

## 🚀 เริ่มต้นใช้งาน
1. คัดลอกไฟล์ทั้งหมดลงในโฟลเดอร์โปรเจกต์
2. ติดตั้ง Dependencies:
   ```bash
   npm install
   ```
3. รันโปรเจกต์ (Development Mode):
   ```bash
   npm run dev
   ```

## 🛡️ การตั้งค่าแอดมิน (Admin Setup)
1. ไปที่ไฟล์ `contexts/AuthContext.tsx`
2. แก้ไขตัวแปร `ADMIN_EMAIL` เป็นอีเมลที่คุณต้องการให้เป็นแอดมิน
3. สมัครสมาชิกในหน้าเว็บด้วยอีเมลดังกล่าว ระบบจะมอบสิทธิ์ Admin ให้โดยอัตโนมัติ

## 🛡️ ความปลอดภัย (Security)
- ระบบเชื่อมต่อกับ Firebase Auth และ Firestore
- อย่าลืมตั้งค่า **Firestore Security Rules** ใน Firebase Console เพื่อจำกัดสิทธิ์ Admin ในการเข้าถึงข้อมูลที่สำคัญ

---
สร้างโดย Senior Frontend Engineer เพื่อการใช้งานจริง
